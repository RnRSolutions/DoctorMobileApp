// // import 'dart:convert';
// // import 'package:agora_uikit/agora_uikit.dart';
// // import 'package:flutter/material.dart';
// // import 'package:http/http.dart';
// //
// //
// // class VideoCall extends StatefulWidget {
// //   String channelName = "rNrDocApp";
// //
// //   VideoCall({required this.channelName});
// //   @override
// //   _VideoCallState createState() => _VideoCallState();
// // }
// //
// // class _VideoCallState extends State<VideoCall> {
// //   late final AgoraClient _client;
// //   bool _loading = true;
// //   String tempToken = "007eJxTYLgWV5xv7HrG93Cue4b0wciwQ3XTdmoc4GT38Zf2u/td/bsCQ7KZWZJFmmGakUGKkYlxakqioYGRYaKZmaVlsomFSYpB1N5baQ2BjAwB8lUsjAwQCOJzMhT5FbnkJzsWFDAwAACJRh+2";
// //
// //   @override
// //   void initState() {
// //     getToken();
// //     super.initState();
// //   }
// //
// //   Future<void> getToken() async {
// //     String link =
// //         "https://agora-node-tokenserver-1.davidcaleb.repl.co/access_token?channelName=${widget.channelName}";
// //
// //     Response _response = await get(Uri.parse(link));
// //     Map data = jsonDecode(_response.body);
// //     setState(() {
// //       tempToken = data["token"];
// //     });
// //     _client = AgoraClient(
// //         agoraConnectionData: AgoraConnectionData(
// //           appId: "c66b8f1f20d243eda1021a6699c484d0",
// //           tempToken: tempToken,
// //           channelName: widget.channelName,
// //
// //         ),
// //         enabledPermission: [Permission.camera, Permission.microphone]);
// //     Future.delayed(Duration(seconds: 1)).then(
// //       (value) => setState(() => _loading = false),
// //     );
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       body: SafeArea(
// //         child: _loading
// //             ? Center(
// //                 child: CircularProgressIndicator(),
// //               )
// //             : Stack(
// //                 children: [
// //                   AgoraVideoViewer(
// //                     client: _client,
// //                   ),
// //                   AgoraVideoButtons(client: _client)
// //                 ],
// //               ),
// //       ),
// //     );
// //
// //   }
// // }
// //
// //
// //
// //
// //
//
//
// import 'dart:convert';
// import 'package:agora_uikit/agora_uikit.dart';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
// import 'package:permission_handler/permission_handler.dart';
//
// class VideoCall extends StatefulWidget {
//   final String channelName;
//
//   VideoCall({required this.channelName});
//
//   @override
//   _VideoCallState createState() => _VideoCallState();
// }
//
// class _VideoCallState extends State<VideoCall> {
//   late AgoraClient _client;
//   bool _loading = true;
//   String tempToken = "007eJxTYLgWV5xv7HrG93Cue4b0wciwQ3XTdmoc4GT38Zf2u/td/bsCQ7KZWZJFmmGakUGKkYlxakqioYGRYaKZmaVlsomFSYpB1N5baQ2BjAwB8lUsjAwQCOJzMhT5FbnkJzsWFDAwAACJRh+2";
//
//   @override
//   void initState() {
//     super.initState();
//     _initializeAgora();
//   }
//
//   Future<void> _initializeAgora() async {
//     // Check and request permissions
//     await _requestPermissions();
//
//     // Fetch token and initialize Agora Client
//     await _fetchToken();
//     setState(() {
//       _client = AgoraClient(
//         agoraConnectionData: AgoraConnectionData(
//           appId: "c66b8f1f20d243eda1021a6699c484d0",
//           tempToken: tempToken,
//           channelName: widget.channelName,
//         ),
//         enabledPermission: [Permission.camera, Permission.microphone],
//       );
//       _loading = false;
//     });
//   }
//
//   Future<void> _requestPermissions() async {
//     final status = await [
//       Permission.camera,
//       Permission.microphone,
//     ].request();
//
//     if (status[Permission.camera] != PermissionStatus.granted ||
//         status[Permission.microphone] != PermissionStatus.granted) {
//       // Handle permissions not granted
//       print('Camera and/or microphone permissions not granted');
//     }
//   }
//
//   Future<void> _fetchToken() async {
//     String link =
//         "https://agora-node-tokenserver-1.davidcaleb.repl.co/access_token?channelName=${widget.channelName}";
//
//     final response = await http.get(Uri.parse(link));
//     if (response.statusCode == 200) {
//       final data = jsonDecode(response.body);
//       setState(() {
//         tempToken = data["token"];
//       });
//     } else {
//       // Handle token fetch failure
//       print('Failed to fetch token');
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: SafeArea(
//         child: _loading
//             ? Center(child: CircularProgressIndicator())
//             : Stack(
//           children: [
//             AgoraVideoViewer(
//               client: _client,
//             ),
//             AgoraVideoButtons(client: _client),
//           ],
//         ),
//       ),
//     );
//   }
// }


import 'dart:convert';
import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:agora_uikit/agora_uikit.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class VideoCall extends StatefulWidget {
  final String channelName = "rNrDocApp";

  // VideoCall({required this.channelName});
  VideoCall();
  @override
  _VideoCallState createState() => _VideoCallState();
}

const appId = "c66b8f1f20d243eda1021a6699c484d0";
String token = "007eJxTYKhr6veatfrOe5bopLka8p5pj59EiWlKsCdsKvBJuXmH95wCQ7KZWZJFmmGakUGKkYlxakqioYGRYaKZmaVlsomFSYrBvcI7aQ2BjAwvpFOZGBkgEMTnZCjyK3LJT3YsKGBgAAChJCBd";
String channel = "rNrDocApp";

class _VideoCallState extends State<VideoCall> {

  int? _remoteUid;
  bool _localUserJoined = false;
  late RtcEngine _engine;

  @override
  void initState() {
    super.initState();
    initAgora();
  }

  Future<void> initAgora() async {
    // fetch token
    await _fetchToken();

    // retrieve permissions
    await [Permission.microphone, Permission.camera].request();

    //create the engine
    _engine = createAgoraRtcEngine();
    await _engine.initialize(const RtcEngineContext(
      appId: appId,
      channelProfile: ChannelProfileType.channelProfileLiveBroadcasting,
    ));

    _engine.registerEventHandler(
      RtcEngineEventHandler(
        onError: (ErrorCodeType error, String code) {
          final info = 'LOG::onError: $code';
          debugPrint(info);
        },
        onJoinChannelSuccess: (RtcConnection connection, int elapsed) {
          debugPrint("local user ${connection.localUid} joined");
          setState(() {
            _localUserJoined = true;
          });
        },
        onUserJoined: (RtcConnection connection, int remoteUid, int elapsed) {
          debugPrint("remote user $remoteUid joined");
          setState(() {
            _remoteUid = remoteUid;
          });
        },
        onUserOffline: (RtcConnection connection, int remoteUid, UserOfflineReasonType reason) {
          debugPrint("remote user $remoteUid left channel");
          setState(() {
            _remoteUid = null;
          });
        },
        onTokenPrivilegeWillExpire: (RtcConnection connection, String token) {
          debugPrint(
              '[onTokenPrivilegeWillExpire] connection: ${connection.toJson()}, token: $token');
        },
      ),
    );

    await _engine.setClientRole(role: ClientRoleType.clientRoleBroadcaster);
    await _engine.enableVideo();
    await _engine.startPreview();

    await _engine.joinChannel(
      token: token,
      channelId: channel,
      uid: 0,
      options: const ChannelMediaOptions(
        publishCameraTrack: true
      ),
    );
    debugPrint("USER JOINED");
    // setState(() {
    //   _localUserJoined = true;
    // });
    debugPrint("${_localUserJoined}");
  }

  Future<void> _fetchToken() async {
    String link =
        "https://ae7a5c55-1dd9-40b9-aed8-7945d7127043-00-2rcm1dx5px2xq.pike.replit.dev/rtc/${widget.channelName}/publisher/uid/0";

    final response = await http.get(Uri.parse(link));
    debugPrint("response");
    debugPrint(response as String?);
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      debugPrint("data");
      debugPrint(data);
      setState(() {
        token = data["rtcToken"];
      });
    } else {
      // Handle token fetch failure
      print('Failed to fetch token');
    }
  }

  @override
  void dispose() {
    super.dispose();

    _dispose();
  }

  Future<void> _dispose() async {
    await _engine.leaveChannel();
    await _engine.release();
  }

  // Create UI with local view and remote view
  @override
  Widget build(BuildContext context) {

    final AgoraClient client = AgoraClient(
      agoraConnectionData: AgoraConnectionData(
          appId: appId,
          channelName: channel,
          tempToken: token
      ),
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text('Agora Video Call'),
      ),
      body: Stack(
        children: [
          Center(
            child: _remoteVideo(),
          ),
          Align(
            alignment: Alignment.topLeft,
            child: SizedBox(
              width: 100,
              height: 150,
              child: Center(
                child: _localUserJoined
                    ? AgoraVideoView(
                  controller: VideoViewController(
                    rtcEngine: _engine,
                    canvas: const VideoCanvas(uid: 0),
                  ),
                )
                    : const CircularProgressIndicator(),
              ),
            ),
          ),
          AgoraVideoButtons(client: client,)

        ],
      ),
    );
  }

  // Display remote user's video
  Widget _remoteVideo() {
    if (_remoteUid != null) {
      return AgoraVideoView(
        controller: VideoViewController.remote(
          rtcEngine: _engine,
          canvas: VideoCanvas(uid: _remoteUid),
          connection: RtcConnection(channelId: channel),
        ),
      );
    } else {
      return const Text(
        'Please wait for remote user to join',
        textAlign: TextAlign.center,
      );
    }
  }

}